# API de Reconhecimento Facial
# Pacote principal da aplicação 